import  "../styles/pages/paciente2.css";


const Paciente2= () => {
    return (
    <div style={{textAlign: 'center'}}>
        <h1 style={{ border: "1px solid blue"}}>Datos del paciente 2</h1>
    </div>
    );
};
export default Paciente2;