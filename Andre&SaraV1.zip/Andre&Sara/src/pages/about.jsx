import React from "react";
import  "../styles/pages/about.css";


const About= () => {
  return (
    <div style={{textAlign: 'center'}}>
      <h1 style={{ border: "1px solid blue"}}>¿Quiénes somos?</h1>
      <h2> Somos dos estudiantes de ingeniería biomédica cursando séptimo semestre. 
        Nuestros nombres son: Sara Nieto Isaza y Andrea Alejandra Parra Ossa. </h2>
      <img src="./images/Image1.jpeg" alt="My Logo" style={{ width: '500px', height: 'auto' }} />
      <h2>¡Ójala nuestros datos recolectados te sean de ayuda!</h2>
      <p>Si tienes alguna duda no dudes en contactarnos al +57 3106777777</p>
      <img src="./images/Image2.jpg" alt="My Logo" style={{ width: '500px', height: 'auto' }} />
      <p>¡¡Estamos pendientes!!</p>
    </div>
  );
};

export default About;
