
const Index = () => {
  return (
    <div style={{ textAlign: "center" }}>
      <h1 style={{ border: "1px solid blue",}} >A&S neurosciencias</h1>
      <h2> Una empresa a cargo de tomar muestras de desarrollo cerebral de pacientes in vitro y mostrar sus resultados en vivo </h2>
      <img src="./images/brain.png" alt="My Logo" />
      <h2> Para consultarlos primero debes ver si los resultados ya fueron tomados, para eso tendrás que revisar si estan diponibles en la ventana llamada "Disponibilidad de los datos", ¡si la respuesta es afirmativa los puedes consultar!</h2>
    </div>
  );
};

export default Index;
