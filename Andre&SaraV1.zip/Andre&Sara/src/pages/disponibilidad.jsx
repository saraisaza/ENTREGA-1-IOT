import  "../styles/pages/disponibilidad.css";

const Available= () => {
    return (
    <div style={{textAlign: 'center'}}>
        <h1 style={{ border: "1px solid blue"}}>¿Ya se tomaron los datos?</h1>
    </div>
    );
};

export default Available;

