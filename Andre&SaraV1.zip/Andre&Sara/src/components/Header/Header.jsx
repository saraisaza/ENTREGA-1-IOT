import React from "react";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";

import Index from "../../pages/index";
import About from "../../pages/about";

import "./header.css";
import Available from "../../pages/disponibilidad";
import Paciente2 from "../../pages/paciente2";
import Patient1 from "../../pages/paciente1";

const Header = () => {
  return (
    <Router>
      <div className="header">
        <h1>A&S Análisis de pacientes</h1>
        <ul>
          <div>
            <Link to="/about">¿Quiénes somos?</Link>
          </div>
          <div>
            <Link to="/disponibilidad">Disponibilidad de los datos</Link>
          </div>
          <div>
            <Link to="/paciente1">Paciente 1</Link>
          </div>
          <div>
            <Link to="/paciente2">Paciente 2</Link>
          </div>
        </ul>
      </div>
      <Routes>
        <Route exact path="/" element={<Index />}></Route>
        <Route exact path="/home" element={<Index />}></Route>
        <Route exact path="/paciente1" element={<Patient1 />}></Route>
        <Route exact path="/about" element={<About />}></Route>
        <Route exact path="/disponibilidad" element={<Available />}></Route>
        <Route exact path="/paciente2" element={<Paciente2 />}></Route>
      </Routes>
    </Router>
  );
};

export default Header;
