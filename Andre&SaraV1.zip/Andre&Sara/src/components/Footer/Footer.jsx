/*
const Footer = () => {
  return (
    <div>
      <h1>Footer</h1>
    </div>
  );
};
*/

import React from 'react';

function Footer() {
  return (
    <footer>
      <p>Copyright © 2023</p>
      <div>
        <li><a href="/home">Home</a></li>
        <li><a href="/about">Contáctanos</a></li>
      </div>
    </footer>
  );
}

export default Footer;
