import  "../styles/pages/paciente1.css";

const Patient1= () => {
    return (
    <div style={{textAlign: 'center'}}>
        <h1  style={{ border: "1px solid blue"}}>Datos del paciente 1</h1>
    </div>
    );
};

export default Patient1;
